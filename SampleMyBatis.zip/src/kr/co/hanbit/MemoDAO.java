package kr.co.hanbit;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class MemoDAO {
    private String NS="kr.co.hanbit.MemoMapper";
    private SqlSession ses;
    Connection con;
    PreparedStatement pstmt;
    ResultSet rs;
    public MemoDAO(){
    	
    }
    private SqlSessionFactory getSessionFactory(){
    	String resource="config/mybatis-config.xml";
    	InputStream is=null;
    	try {
			is=Resources.getResourceAsStream(resource);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
    	SqlSessionFactory fac=new SqlSessionFactoryBuilder().build(is);
    	return fac;
    }
    
    public List<MemoVO> selectAllMemo() throws SQLException{
        try{
            ses=this.getSessionFactory().openSession();
            List<MemoVO> arr=null;
            arr=ses.selectList(NS+".getMemo");
            return arr;            
        }finally{
            if(ses!=null) ses.close();
        }
    }//----------------------------------------
    
    public void close(){
        try {
            if(rs!=null) rs.close();
            if(pstmt!=null) pstmt.close();
            if(con!=null) con.close();
        } catch (Exception e) {
        }
    }//close()----------------------------------------

 
    
}///////////////////////////////////////////////




