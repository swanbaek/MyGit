package guest.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class GuestbookVO implements Serializable {

	private Integer idx;
	private String writer;
	private String content;
	private String email;
	private java.sql.Timestamp writedate;
	
	public GuestbookVO() {
		// TODO Auto-generated constructor stub
	}
	
	
	public GuestbookVO(Integer idx, String writer, String content,
			String email, Timestamp writedate) {
		super();
		this.idx = idx;
		this.writer = writer;
		this.content = content;
		this.email = email;
		this.writedate = writedate;
	}


	public Integer getIdx() {
		return idx;
	}

	public void setIdx(Integer idx) {
		this.idx = idx;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public java.sql.Timestamp getWritedate() {
		return writedate;
	}

	public void setWritedate(java.sql.Timestamp writedate) {
		this.writedate = writedate;
	}
	

}
