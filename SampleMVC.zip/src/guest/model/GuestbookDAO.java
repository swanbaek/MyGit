package guest.model;
import java.sql.*;
import java.util.*;
import java.sql.Timestamp;

import javax.sql.*;
import javax.naming.*;
public class GuestbookDAO {
	
	private DataSource ds;
	private Connection con;
	private PreparedStatement ps;
	private ResultSet rs;

	public GuestbookDAO() {
		try {
			Context ctx=new InitialContext();
			ds=(DataSource)ctx.lookup("java:comp/env/myoracle/javadb");
			System.out.println("DS룩업 성공");			
		} catch (Exception e) {
			System.out.println("DataSource룩업 실패: "+e);
		}
	}//------------------
	/**방명록에 글쓰기 처리를 하는 메소드-insert문 수행*/
	public int insertGB(GuestbookVO g) throws SQLException{
		try{
			con=ds.getConnection();
	StringBuilder buf=new StringBuilder("insert into guestbook values(")
			.append("guestbook_idx.nextval,?,?,?,systimestamp)");
			String sql=buf.toString();
			ps=con.prepareStatement(sql);
			ps.setString(1, g.getWriter());
			ps.setString(2, g.getContent());
			ps.setString(3, g.getEmail());
			int n=ps.executeUpdate();
			return n;
		}finally{
			close();
		}
	}//------------------
	
	public void close(){
		try {
			if(rs!=null) rs.close();
			if(ps!=null) ps.close();
			if(con!=null) con.close();
		} catch (Exception e) {
		}
	}//----------------------
	/**총 게시글 수를 알아내자.[페이징 처리에 필요]*/
	public int getTotalCount() throws SQLException{
		try{
			con=ds.getConnection();
			String sql="select count(*) from guestbook";
			ps=con.prepareStatement(sql);
			rs=ps.executeQuery();
			boolean b=rs.next();
			int cnt=rs.getInt(1);
			return cnt;
		}finally{
			close();
		}
	}
	
	
	/**게시글 목록을 가져오는 메소드*/
	public List<GuestbookVO> listGB(int start,int end) throws SQLException{
		try{
			con=ds.getConnection();
			//String sql="select * from guestbook order by idx desc";
			
			StringBuilder buf
			=new StringBuilder("select * from(")
				.append(" select rownum rn, a.* from")
				.append(" (select * from guestbook order by idx desc) a)")
				.append(" where rn between ? and ?");
			String sql=buf.toString();
			//System.out.println(sql);
			
			ps=con.prepareStatement(sql);
			ps.setInt(1, start);
			ps.setInt(2, end);
			rs=ps.executeQuery();
			List<GuestbookVO> arr=new ArrayList<GuestbookVO>();
			while(rs.next()){
				int idx=rs.getInt("idx");
				String writer=rs.getString("writer");
				String content=rs.getString("content");
				String email=rs.getString("email");
				Timestamp wdate=rs.getTimestamp("writedate");
				GuestbookVO vo
				=new GuestbookVO(idx,writer,content,email,wdate);
				arr.add(vo);
			}//while------
			return arr;
		}finally{
			close();
		}
	}

}


