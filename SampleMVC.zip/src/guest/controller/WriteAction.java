package guest.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import common.controller.AbstractAction;

//Controller
public class WriteAction extends AbstractAction{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		
		//뷰 페이지 지정
		//forward방식으로 이동
		this.setViewPage("/write.jsp");
		this.setRedirect(false);//false값을 주면 forward방식으로 이동
					//true값을 주면 redirect방식으로 이동		
	}
}
