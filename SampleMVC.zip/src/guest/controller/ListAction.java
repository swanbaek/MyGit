package guest.controller;

import guest.model.GuestbookDAO;
import guest.model.GuestbookVO;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import common.controller.AbstractAction;

public class ListAction extends AbstractAction {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		// 1. 페이징 처리를 위한 파라미터값 받기
		//보여줄 현재 페이지값 받기
		String cpageStr=req.getParameter("cpage");
		if(cpageStr==null||cpageStr.trim().isEmpty()){
			//cpage파라미터가 넘어오지 않았다면 디폴트로 보여줄
			//페이지를 1 페이지로 정하자.
			cpageStr="1";
		}
		int cpage=Integer.parseInt(cpageStr.trim());
		
		
		// 2. DAO생성해서 글목록 가져오는 메소드 호출
		GuestbookDAO dao=new GuestbookDAO();
		int totalCount=dao.getTotalCount();//총 게시글 수 가져오기
		int pageSize=5;//한 페이지 당 보여줄 목록 갯수
		
		int pageCount=0;//총 페이지 수
		/*
		if(totalCount%pageSize==0){
			//총 게시물수가 5,10,15,20,..단위로 나올 때
			pageCount=totalCount/pageSize;
		}else{			
			pageCount=totalCount/pageSize+1;
		}
		*/
		pageCount=(totalCount-1)/pageSize+1;
		if(pageCount<=0){
			pageCount=1;
		}
		
		int end=cpage*pageSize;
		int start=end-(pageSize-1);
		
		List<GuestbookVO> arr=dao.listGB(start,end);
		
		//3. 그 결과물(ArrayList<GuestbookVO>)을 req에 
		//   저장
		req.setAttribute("total", totalCount);
		req.setAttribute("pageCount", pageCount);
		req.setAttribute("gblist", arr);		
		//4. 뷰페이지 지정 후 forward방식으로 이동
		this.setViewPage("/list.jsp");
		this.setRedirect(false);
	}

}
