package guest.controller;

import guest.model.GuestbookDAO;
import guest.model.GuestbookVO;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import common.controller.AbstractAction;

public class WriteEndAction extends AbstractAction {
	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		// 1.사용자가 입력한 값 받기
		String writer=req.getParameter("writer");
		String email=req.getParameter("email");
		String content=req.getParameter("content");
		//1_2. 유효성 체크
		if(writer==null||writer.trim().isEmpty()){
			this.setViewPage("write.do");
			this.setRedirect(true);//redirect방식으로 이동
			return;
		}		
		// 2. 사용자가 입력한 값을 VO객체에 넣어주기
		GuestbookVO guest=new GuestbookVO(null,writer,content,email,null);
		
		// 3. DAO 객체 생성-insertGB()호출
		GuestbookDAO dao=new GuestbookDAO();		
		// 4. 그 결과 메시지 처리
		int n=dao.insertGB(guest);
		
		String msg=(n>0)?"글쓰기 성공":"글쓰기 실패";
		String loc=(n>0)?"list.do":"write.do";
		
		req.setAttribute("msg", msg);
		req.setAttribute("loc", loc);
		//request에 저장한 값들은 forward이동할 때
		//이동된 페이지에서 공유한다.
		
		// 5. 이동할 페이지 지정
		this.setViewPage("/msg.jsp");
		this.setRedirect(false);//forward방식으로 이동
		
	}

}
