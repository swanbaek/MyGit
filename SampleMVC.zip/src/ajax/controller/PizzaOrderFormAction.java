package ajax.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import common.controller.AbstractAction;

public class PizzaOrderFormAction extends AbstractAction {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		
		this.setViewPage("/Ajax/pizza/orderForm.jsp");
		this.setRedirect(false);
	}

}
