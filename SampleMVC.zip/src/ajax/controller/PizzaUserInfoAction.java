package ajax.controller;

import javax.servlet.http.HttpServletRequest;

import javax.servlet.http.HttpServletResponse;

import common.controller.AbstractAction;
import javax.sql.*;
import java.sql.*;
import javax.naming.*;

public class PizzaUserInfoAction extends AbstractAction {

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		// 1. 사용자의 연락처 받기
		String phone=req.getParameter("phone");
		
		DataSource ds
		=(DataSource)
		(new InitialContext().lookup("java:comp/env/myoracle/javadb"));
		
		Connection con=ds.getConnection();
		String sql
		="select * from pizza_member where phone=?";
		PreparedStatement ps
				=con.prepareStatement(sql);
		ps.setString(1,phone);
		ResultSet rs=ps.executeQuery();
		int count=0;
		int idx=0;
		String name="", phone2="", addr="";
		while(rs.next()){
			count++;
			idx=rs.getInt("idx");
			name=rs.getString("name");
			phone2=rs.getString("phone");
			addr=rs.getString("addr");
		}
		rs.close();
		ps.close();
		con.close();
		
		req.setAttribute("count", count);
		req.setAttribute("userIdx", idx);
		req.setAttribute("userName", name);
		req.setAttribute("userPhone",phone2);
		req.setAttribute("userAddr", addr);
		
		this.setViewPage("/Ajax/pizza/pizzaResult.jsp");
		this.setRedirect(false);

	}

}
