package common.controller;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Map<String, Object> cmdMap
				=new HashMap<String, Object>();
	
	public void init(ServletConfig config)
	throws ServletException{
		System.out.println("init()...");
		//첫 클라이언트 요청시 딱 한번 수행됨.
		//web.xml에 기술되어 있는 propertyConfig에
		//해당하는 init-param 의 value값을 얻어오자.
		String props
		=config.getInitParameter("propertyConfig");
		System.out.println("props="+props);
		Properties pr=new Properties();
		//key,value쌍으로 저장하는 자료구조. Hashtable의
		//자식 클래스. Properties객체에 명령어와
		//처리 클래스의 매핑 정보를 저장하자.
		FileInputStream fis=null;
		try{
			fis=new FileInputStream(props);
			//Command.properties 파일과 노드 연결
			pr.load(fis);
			//Command.properties파일의 정보를
			//Properties객체 저장.
			if(fis!=null) fis.close();
		}catch(IOException e){
			e.printStackTrace();
		}
		
		//String val=pr.getProperty("/guest/writeForm.do");
		//System.out.println("val="+val);
		Enumeration<Object> en=pr.keys();
		//명령어들만 집합체로 받아오자.
		while(en.hasMoreElements()){
			String command=(String)en.nextElement();
			System.out.println("command="+command);
			String className=pr.getProperty(command);
			//클래스명 앞뒤에 공백이 있다면 제거
			if(className!=null){
				className=className.trim();
			}
			
			System.out.println("className="+className);
			try{
			Class  commandClass=Class.forName(className);
			//해당 문자열을 클래스로 만든다.
			Object commandInstance=commandClass.newInstance();
			//해당 클래스의 객체(instance)를 생성해줌.
			
			//이 객체들을 Map에 저장하자.////////
			cmdMap.put(command, commandInstance);
			///////////////////////////////////
			}catch(Exception e){
				e.printStackTrace();
				throw new ServletException(e);
			}
			
		}//while------------
		
		
	}//init()-------------
   

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		requestProcess(request,response);
	}

	protected void doPost(HttpServletRequest request, 
			HttpServletResponse response) 
					throws ServletException, IOException {
		requestProcess(request,response);
	}

	protected void requestProcess(HttpServletRequest 
			req,HttpServletResponse	res) 
	 throws ServletException,IOException{
			System.out.println("FrontController...");
			String viewPage=null;
			AbstractAction action=null;
			try{
			//클의 요청 URI를 분석해보자.
			String cmdURI=req.getRequestURI();
			System.out.println("cmdURI="+cmdURI);
			//cmdURI=/MyWeb/guest/writeForm.do
			String myctx=req.getContextPath();// /MyWeb
			int len=myctx.length();//=>6
			String cmd=cmdURI.substring(len);
			System.out.println("cmd="+cmd);
			//cmd= /guest/writeForm.do
			Object instance=cmdMap.get(cmd);
			action=(AbstractAction)instance;
			if(action==null){
				System.out.println("action이 널");
				return;
			}
			
			//액션의 execute()호출..//////
			action.execute(req, res);
			viewPage=action.getViewPage();
			////////////////////////////
			//View페이지 얻기
			if(viewPage==null){
				System.out.println("viewPage가 널");
				viewPage="index.jsp";
			}		
			if(!action.isRedirect()){
			//페이지 이동---
			//[1]forward이동방식
			RequestDispatcher dispatch
			=req.getRequestDispatcher(viewPage);
			dispatch.forward(req, res);
			//<jsp:forward page="/view.jsp"/>와 동일
			//dispatch.include(req, res);
			//<jsp:include page="/view.jsp"/>와 동일
			}else{			
				// [2]redirect이동방식
				res.sendRedirect(viewPage);
			}//else----------
			}catch(Exception e){
				e.printStackTrace();
			}
	}//requestProcess()-------------

}///////////////////////////////////////









