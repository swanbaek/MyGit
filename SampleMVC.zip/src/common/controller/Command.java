package common.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//인터페이스: 추상메소드, 상수
/*1) 메소드: public abstract 지정자가 자동으로 붙는다.
 * 2) 상수 : public static final지정자가 자동으로 붙는다.
 * */
public interface Command {

	void execute(HttpServletRequest req, 
			HttpServletResponse res)
	throws Exception;
	
}//////////////////





