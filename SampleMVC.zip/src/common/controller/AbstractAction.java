package common.controller;

abstract public class AbstractAction 
	implements Command{
	//execute()추상메소드를 Command에서 상속받아 가지고 있음
	private String viewPage;
	private boolean isRedirect=false;
	
	//setter, getter---
	
	public String getViewPage() {
		return viewPage;
	}
	public void setViewPage(String viewPage) {
		this.viewPage = viewPage;
	}
	public boolean isRedirect() {
		return isRedirect;
	}
	public void setRedirect(boolean isRedirect) {
		this.isRedirect = isRedirect;
	}
}/////////////////////////////
