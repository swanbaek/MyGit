package common.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//Controller역할=>AbstractAction을 상속받는다.
// 추상클래스->추상메소드를 재정의해야 함(동일한 메소드를 재정의)
public class IndexAction extends AbstractAction{

	@Override
	public void execute(HttpServletRequest req, HttpServletResponse res)
			throws Exception {
		System.out.println("IndexAction컨트롤러 execute()호출됨");
		//로직이 필요하면 로직을 수행
		
		//뷰페이지 지정
		this.setViewPage("/index.jsp");
		//뷰로 이동할 방법 지정
		this.setRedirect(false);//forward방식으로 이동
		
	}

	
}
