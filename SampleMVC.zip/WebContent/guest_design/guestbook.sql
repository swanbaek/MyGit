create table guestbook(
	idx number(8) primary key,
	writer varchar2(30) not null,
	content varchar2(1000),
	email varchar2(100),
	writedate timestamp default systimestamp
);
create sequence guestbook_idx nocache;