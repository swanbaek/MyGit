create table pizza_member(
	idx number(4) primary key,
	name varchar2(20),
	phone varchar2(20) not null,
	addr varchar2(200) not null
);

create sequence pizza_member_idx nocache;

insert into pizza_member
values(pizza_member_idx.nextval,'홍길동',
'02-111-1111','서울 강남구 역삼동 1번지');

insert into pizza_member
values(pizza_member_idx.nextval,'최길동',
'02-222-1111','서울 서초구 서초동 2번지');

Commit;
