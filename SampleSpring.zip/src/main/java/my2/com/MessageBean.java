package my2.com;

public interface MessageBean {
	
	void sayHello(String name);

}
