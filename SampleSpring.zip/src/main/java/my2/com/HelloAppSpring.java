package my2.com;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class HelloAppSpring {

	public static void main(String[] args) {

		String config="classpath:applicationContext.xml";	
		ApplicationContext ctx=new GenericXmlApplicationContext(config);
		MessageBean m1=(MessageBean)ctx.getBean("mb1");
		m1.sayHello("최길동");
		
		MessageBean m2=ctx.getBean("mb2", MessageBean.class);
		m2.sayHello("최길동");

	}

}
