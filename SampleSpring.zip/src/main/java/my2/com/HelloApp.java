package my2.com;

public class HelloApp {

	public static void main(String[] args) {
		MessageBean mb1//=new MessageBeanEn();
			=new MessageBeanKo();
		
		mb1.sayHello("김길동");

	}

}
