package my2.com;

public class MessageBeanEn implements MessageBean {

	@Override
	public void sayHello(String name) {
		// TODO Auto-generated method stub
		System.out.println("Hello? "+name+"!!");

	}

}
