package my3.com;
import java.io.*;

public interface Outputter {
	void output(String msg) throws IOException;
}
