package my3.com;

import java.io.IOException;

public class ConsoleOutputter implements Outputter {

	private String path;

	/**
	 * @return the path
	 */
	public String getPath() {
		return path;
	}
	/**
	 * @param path the path to set
	 */
	public void setPath(String path) {
		this.path = path;
	}

	@Override
	public void output(String msg) throws IOException {
		System.out.println(msg);
		System.out.println(path);
	}

}
