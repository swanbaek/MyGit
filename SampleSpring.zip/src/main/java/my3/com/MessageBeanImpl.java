package my3.com;

import java.io.IOException;

public class MessageBeanImpl implements MessageBean {

	//property-----
	private String name;
	private String greeting;
	
	private String msg;
	private int money;
	
	private Outputter out;
	
	/**
	 * @return the out
	 */
	public Outputter getOut() {
		return out;
	}
	/**
	 * @param out the out to set
	 */
	public void setOut(Outputter out) {
		this.out = out;
	}
	//constructor
	public MessageBeanImpl(){
		
	}
	public MessageBeanImpl(String name, String greeting) {
		super();
		this.name = name;
		this.greeting = greeting;
	}
	public MessageBeanImpl(String msg, int m){
		this.msg=msg; this.money=m;
	}
	@Override
	public void sayHello() {
		System.out.println(greeting+" "+name+"~~");
		System.out.println(msg+">>>"+money);
	}
	@Override
	public void sayHi(String... args) {
		// TODO Auto-generated method stub
		if(args!=null){
			try{
				for(String str:args){
					out.output(str+" 님아~~"+msg);
				}//for---
			}catch(IOException e){}
		}//if--------
	}//-------------------------------

	//setter,getter
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the greeting
	 */
	public String getGreeting() {
		return greeting;
	}
	/**
	 * @param greeting the greeting to set
	 */
	public void setGreeting(String greeting) {
		this.greeting = greeting;
	}


}
