package my3.com;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class HelloAppSpring {

	public static void main(String[] args) {
		
		String config="classpath:applicationContext.xml";
		ApplicationContext ctx
			=new GenericXmlApplicationContext(config);
		MessageBean mb3=ctx.getBean("mb3",MessageBean.class);
		mb3.sayHello();
		mb3.sayHi("현빈","원빈","우빈");

	}

}
