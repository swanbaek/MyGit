package my3.com;
import java.io.FileWriter;
import java.io.IOException;
public class FileOutputter implements Outputter {
	private String path;
	
	@Override
	public void output(String msg) throws IOException {
		FileWriter fw=new FileWriter(path,true);
		fw.write(msg);
		fw.flush();
		if(fw!=null) fw.close();
	}

	/**
	 * @return the path
	 */
	public String getPath() {
		return path;
	}

	/**
	 * @param path the path to set
	 */
	public void setPath(String path) {
		this.path = path;
	}

}
