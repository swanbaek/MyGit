package my3.com;

public interface MessageBean {
	
	void sayHello();
	void sayHi(String ... args);

}
