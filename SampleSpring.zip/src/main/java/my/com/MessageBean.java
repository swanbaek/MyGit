package my.com;

public class MessageBean {
	
	public void sayHello(String name){
		System.out.println("Hello "+name+"~~");
	}

}
