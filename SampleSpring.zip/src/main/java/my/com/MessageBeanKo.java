package my.com;

public class MessageBeanKo {
	
	public void sayHello(String name){
		System.out.println("안녕하세요? "+name+"~~");
	}

}
