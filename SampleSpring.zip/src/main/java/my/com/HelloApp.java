package my.com;

public class HelloApp {

	public static void main(String[] args) {
		
//		MessageBean mb=new MessageBean();
//		mb.sayHello("홍길동");
		MessageBeanKo mk=new MessageBeanKo();
		mk.sayHello("홍길동");

	}

}
